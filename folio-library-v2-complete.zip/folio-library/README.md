# Folio — Personal Library v2

A private, mobile-first personal library for phone and desktop. Built with **HTML, CSS and vanilla JavaScript only**. No React, libraries, server, account, or cloud database.

## Start the app

**Desktop:** Unzip the project. For best results run a local static server in this directory, for example:

```sh
python -m http.server 8000
```

Then open `http://localhost:8000` in your browser. There is no backend: the server only provides static files.

**Phone:** Put the static project on HTTPS hosting (such as GitHub Pages or another static host), then visit the URL from your phone. You may install it to your Home Screen if your browser offers the installation option. Phone and computer each keep **separate local databases**. To transfer books, export JSON on one device and import it on the other.

**Single file:** `folio-standalone.html` opens as a portable demonstration without needing the other files. Some browsers restrict local HTML access to persistent storage and camera APIs. For reliable everyday use, prefer the multi-file version hosted on HTTPS. It can also run via `localhost` on desktop.

## Features

- Responsive home dashboard with book count, currently reading and library purchase value.
- Book CRUD including metadata, ISBN-10/13, genres, shelf, tags, quantity, price, year, publisher, language, cover, optional reading dates.
- Search title, author, ISBN, publication year, price, description, statuses, shelf, tags and note contents.
- Filter genre/shelf/tag/status and year/price ranges, sort, grid/list views.
- Reading progress, reading status, editable dated notes and favorite flag.
- Books by shelf: create, rename and remove shelves (removing shelf preserves its books).
- IndexedDB persistence, full JSON backups with embedded uploaded covers, safe import preview and merge/restore strategies, CSV export and import.
- Manual ISBN entry, ISBN checksum validation, automatic metadata lookup via Open Library with Google Books as a fallback. Only ISBN is sent to these services.
- Mobile camera scanner using native BarcodeDetector where supported; a simple zero-dependency EAN-13 canvas decoder as a best-effort fallback. Supports 978/979 book barcodes. Manual entry always works.
- Light/dark/system modes and forest/ocean/violet/terracotta/rose/amber accent palettes.
- Installable PWA and offline static shell when hosted via HTTPS or localhost (service worker). Remote ISBN lookup does **not** work offline.
- First-run migration from the v1 `folio-prototype-v1` browser localStorage collection when the browser origin is the same.

## Persistence and backups

- The primary storage is a local IndexedDB database named `folio-personal-library`. Books, shelves, and deletion history are stored there.
- On browsers that disable IndexedDB in certain environments (including some `file://` contexts), the app uses **localStorage fallback**, visibly noted in Settings. LocalStorage has much smaller capacity and is not recommended for a large collection or frequent cover uploads.
- The current export schema is `folio-personal-library`, version **2**. JSON version **1** exported by the prototype can also be imported. Data includes uploaded covers in base64 form.
- Before a restore, the app shows a preview and gives three options: **merge while keeping local records**, **merge preferring imported records**, or **replace the entire collection**. Duplicate titles/ISBNs are matched conservatively and their dated notes are combined. Importing does not automatically apply deletions from another device; use full restore for an exact mirror.
- Merging is a practical manual transfer, **not** automated conflict resolution or synchronization. When making independent changes on both devices, keep a backup before merging and check the results.
- CSV loses note history structure, compared with JSON; prefer JSON for complete transfers.
- Browser storage may be erased by user settings, private-browsing policies, storage eviction or device damage. Export JSON copies regularly and keep them somewhere safe.

## Important constraints

- The site is fully client-side. "Backend" here means local browser data operations; **there is no network server or remote database**.
- API metadata may be inaccurate or incomplete. The app asks you to review it before saving; your manually entered fields are not overwritten by lookups.
- Native barcode detection and the built-in EAN-13 fallback depend on lighting, focus, camera permission and browser support. Scanning must be tested on real devices, not assumed to work everywhere.
- External cover URLs may require internet access. Locally uploaded covers are saved in the database and exported in JSON backups.
- Only EUR purchase totals are supported in this version. Books without recorded prices are excluded and counted separately. Total is the sum of price × copies, not estimated resale value.
- For an offline Home Screen installation, host the multi-file project over HTTPS. A service worker cannot normally install from `file://`.

## Files

```
index.html              UI structure, navigation and SVG icons
styles.css              Layout, themes, responsive rules
app.js                  Screen rendering, interaction and book management
barcode.js              Zero-dependency EAN-13 barcode scanner fallback
db.js                   IndexedDB and localStorage fallback
sw.js                   Service worker, offline static shell
manifest.webmanifest    Installable app manifest
assets/covers/*.svg     Original sample book cover illustrations
assets/icons/*.png      App icons
folio-standalone.html   Single-file build for easy preview and transfer
```

## Manual phone test checklist

1. Open the library on HTTPS and try navigating one-handed, including changing accent and dark mode.
2. Add a book manually, upload a cover, add multiple notes, edit a note and update reading progress. Refresh: all data should remain.
3. Scan the ISBN-13 barcode of a real book. If the browser has no native detector, the fallback may require steady framing; the manual ISBN input remains available.
4. With internet, use ISBN lookup and inspect autofilled author/title/pages. Disable internet: your locally saved books should still be accessible after the app assets have been cached.
5. Export JSON, add another book, then test merge and full restore in Settings. **Always keep an independent copy before full restore.**
6. Transfer JSON to another device and import. Verify note history and covers.

## Tests

Static JS syntax, scanner sample-pattern decoding, and application smoke tests for book CRUD, notes, library storage fallback, and JSON merge were run during build. Live phone camera scanning, real ISBN API responses, PWA installation and cross-browser mobile UI still need end-user verification on actual devices.
